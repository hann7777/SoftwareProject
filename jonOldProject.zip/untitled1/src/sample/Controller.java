package sample;

import javafx.beans.value.ObservableIntegerValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ArrayList;
import java.util.Observable;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    //define which fetures why will use from sample.fxml
    @FXML
    private Button addButton;
    @FXML
    private Button Button3;
    @FXML
    private ListView reservationsListView;
    @FXML
    private ListView reservationsListView2;
    @FXML
    private TextField departureTextField;
    @FXML
    private TextField arrivalTextField;
    @FXML
    private TextField dateTextField;
    @FXML
    private ListView availableFlights;
    @FXML
    private ComboBox CBarrival;
    @FXML
    private ComboBox CBdeparture;
    @FXML
    private ComboBox CBdate;
    @FXML
    private ComboBox HowMany;



    private DataFactory dataFactory = new DataFactory();
    //flights to be imported from data factory
    private ObservableList<Flights> flights=FXCollections.observableArrayList();
    //list of filtered flights
    private ObservableList<Flights> flightsf=FXCollections.observableArrayList();
    //flights removed from view
    private ObservableList<Flights> flightsd=FXCollections.observableArrayList();
    //which flights is selected from available flights
    private ObservableList<Flights> val=FXCollections.observableArrayList();
    //which flights is selected from booked flights
    private ObservableList<Reservation> val2=FXCollections.observableArrayList();
    //reservations for booked flights
    private ObservableList<Reservation> flighsb=FXCollections.observableArrayList();
    //list of airports
    private ObservableList<Airport> airports = FXCollections.observableArrayList();
    //list of dates
    private ObservableList<Date> dates = FXCollections.observableArrayList();
    //list of numbers for a combobox
    private ObservableList<Integer> numbers = FXCollections.observableArrayList();

    //information to be used
    public int  i=0;
    public String  i1="0";
    public String  i2="0";
    public String  i3="0";

    //to see if comboboxes have been used
    public void CBdateAction(ActionEvent event){
        i1="1";
    }
    public void CBarrivalAction(ActionEvent event){
        i2="1";
    }
    public void CBdepartureAction(ActionEvent event){
        i3="1";
    }
    //search function
    public void addButtonOnActivity(ActionEvent event) { 
       // initializing flighsf
        flightsf = FXCollections.observableArrayList();

        String filter = departureTextField.getText();
        String filter2 = arrivalTextField.getText();
        String filter3 = dateTextField.getText();
        String filter4;
        String filter5;
        String filter6;
        //if combobox is not empty use value, if else than empty
        if (i1.equals("1")){
            filter6=CBdate.getSelectionModel().getSelectedItem().toString();
        } else{
            filter6="";
            System.out.println("else");
        }
        if (i2.equals("1")){
            filter4=CBarrival.getSelectionModel().getSelectedItem().toString();
        }else{
            filter4="";
        }
        if (i3.equals("1")){
            filter5=CBdeparture.getSelectionModel().getSelectedItem().toString();
        }else{
            filter5="";
        }

        //Filter by search values and/or combobox values, if search is empty ""
        for (Flights u : flights){
            if (u.getBrottfor().contains(filter) && u.getAfangastadur().contains(filter2)&& u.getDagsetning().contains(filter3) &&
                    u.getBrottfor().contains(filter5) && u.getAfangastadur().contains(filter4)&&u.getDagsetning().contains(filter6)) {
                flightsf.add(u);
                System.out.println(u);
            }
        }

        //show searched flights and refresh
        availableFlights.setItems(flightsf);
        availableFlights.refresh();
        }



    @Override
    public void initialize(URL location, ResourceBundle resource) {
        //put in inital values from datafactory
        flights = dataFactory.getFlights();
        airports = dataFactory.getAirport();
        dates = dataFactory.getDate();
        availableFlights.setItems(flights);
        //add numbers to combobox
        for (int i=1;i<10;i++) {
            numbers.add((int) i);
        }
        CBarrival.getItems().addAll(airports);
        CBdeparture.getItems().addAll(airports);
        CBdate.getItems().addAll(dates);
        HowMany.getItems().addAll(numbers);
        //set default value to 1
        HowMany.getSelectionModel().selectFirst();

    }
    //booking button
    public void addButtonOnActivity2(ActionEvent event2) {
        int j=i;
        //check what flight has been selected
        Flights selectedItem = (Flights) availableFlights.getSelectionModel().getSelectedItem();
        //how many seats are to be (Book)ed
        int nr = (int) HowMany.getSelectionModel().getSelectedItem();
        //removing booked seats from selected flight
        if (selectedItem.getCapacity()-nr>=0) {
            for (i = 0; i < nr; i++) {
                selectedItem.reduceCapacity();
            }
            //for the first flight booked to
         //   if (j == 0) {
           //     i = 1;
         //       flighsb.add(new Reservation(selectedItem));
         //       for (i = 0; i < nr; i++) {
         //           flighsb.get(0).addCapacity();
         //       }
                reservationsListView2.setItems(flighsb);
         //   } else {
                int b = 0;
                //check if the flight being booked already has a reservation
                for (Reservation u : flighsb) {
                    if (selectedItem.equals(u.getFlight())) {
                        //if it does than we add passengers
                        for (i = 0; i < nr; i++) {
                            u.addCapacity();
                        }
                        b = 1;
                    }
                }
                if (b == 0) {
                    //if it doesnt then we add a new reservation for that flight
                    flighsb.add(new Reservation(selectedItem));
                    for (Reservation u : flighsb) {
                        if (selectedItem.equals(u.getFlight())) {
                            for (i = 0; i < nr; i++) {
                                u.addCapacity();
                            }
                        }
                    }
                }
           // }

        }
        //check if any flight has zero passengers than remove it from view
        for (Flights u : flights) {
            if (u.getCapacity()<=0) {
                //add our flight to deleted flights
                flightsd.add(u);
                //remove our flight from flights
                flights.remove(u);
                availableFlights.refresh();
                reservationsListView.refresh();
                reservationsListView2.refresh();
            }
        }
        //refresh
            availableFlights.refresh();
            reservationsListView.refresh();
            reservationsListView2.refresh();
        }


//flights selected from available flights
    public void listViewMouseClicked(MouseEvent mouseEvent) {
        //initalize val to hold our flight for further use
        val = FXCollections.observableArrayList();
        //add our selected flight to val
        val.add((Flights) availableFlights.getSelectionModel().getSelectedItem());
        //add the selected flight to the selected flight window
        reservationsListView.setItems(val);
        //refresh
        availableFlights.refresh();
    }

    //flights selected from booked flights
    public void listViewMouseClicked2(MouseEvent mouseEvent) {
        //same as before but for booked flights
        val2 = FXCollections.observableArrayList();
        val2.add((Reservation) reservationsListView2.getSelectionModel().getSelectedItem());
        reservationsListView.setItems(val2);
        availableFlights.refresh();
        reservationsListView.refresh();
        reservationsListView2.refresh();
    }

    //button to unbook flight
    public void addButtonOnActivity3(ActionEvent event2) {
        //store selected reservation
        Reservation selectedItem = (Reservation) reservationsListView2.getSelectionModel().getSelectedItem();
        //how many seats are to be unbooked
        int nr = (int) HowMany.getSelectionModel().getSelectedItem();
        //see if the seats being unbooked aren't more than are booked
        if (selectedItem.getBookedSeats()-nr>=0) {
            //remove seats from reservation
            for (i = 0; i < nr; i++) {
                selectedItem.reduceCapacity();
            }
            //add capacity to flights
            for (Flights u : flights) {
                if (selectedItem.getFlight().equals(u)) {
                    for (i = 0; i < nr; i++) {
                        u.addCapacity();
                    }
                }
            }
        }
// adding the flight back to view if the flight has been removed
        for (Flights v: flightsd) {
            if (selectedItem.getFlight().equals(v)) {
                for (i=0;i<nr;i++) {
                    v.addCapacity();
                }
                    flights.add(v);
                    availableFlights.setItems(flights);
                    flightsd.remove(v);
                    availableFlights.refresh();
                    reservationsListView.refresh();
                    reservationsListView2.refresh();
            }
        }
        //remove all empty bookings
        for (Reservation u : flighsb){
            if (u.getBookedSeats()==0){
                flighsb.remove(u);
                reservationsListView.refresh();
                reservationsListView2.refresh();
                availableFlights.refresh();
            }
        }
        reservationsListView.refresh();
        reservationsListView2.refresh();
        availableFlights.refresh();
    }

}



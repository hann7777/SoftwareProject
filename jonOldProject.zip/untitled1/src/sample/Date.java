package sample;

public class Date {
    public Date(String date) {
        Date = date;
    }
    @Override
    public String toString() {
        return  Date;
    }

    private String Date;
}

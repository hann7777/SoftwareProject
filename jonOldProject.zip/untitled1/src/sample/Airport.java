package sample;

public class Airport {
    private String Name;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public Airport(String Name) {
        this.Name = Name;
    }

    @Override
    public String toString() {
        return Name;
    }
}

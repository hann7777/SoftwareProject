package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;


public class DataFactory {
    public DataFactory() {
    }

    public ObservableList<Flights> getFlights(){
        ObservableList<Flights> flights= FXCollections.observableArrayList();
        ArrayList<Flights> Flights = new ArrayList<>();

        String date1 = "20/03/21";
        String date2 = "08/07/21";
        String date3 = "02/09/21";
        String date4 = "12/04/21";
        String date5 = "19/11/21";
        String date6 = "30/12/21";
        String date7 = "20/02/21";
        String date8 = "15/01/21";
        String date9 = "26/08/21";
        String date10 = "03/10/21";
        String date11 = "27/09/21";
        String date12 = "17/06/21";



        flights.add(new Flights(date1, "KEF","FRK",10));
        flights.add(new Flights(date2, "FRK","MRD",10));
        flights.add(new Flights(date3, "BOS","OSL",24));
        flights.add(new Flights(date2, "MSK","OSL",34));
        flights.add(new Flights(date11, "MSK","TOK",50));
        flights.add(new Flights(date4, "STK","HEL",23));
        flights.add(new Flights(date5, "LDN","FRK",45));
        flights.add(new Flights(date2, "MSK","TOK",50));
        flights.add(new Flights(date1, "MSK","COP",19));
        flights.add(new Flights(date6, "PAR","COP",17));
        flights.add(new Flights(date2, "KEF","BOS",24));
        flights.add(new Flights(date3, "MSK","TOK",50));
        flights.add(new Flights(date7, "ROM","NYC",35));
        flights.add(new Flights(date5, "HEL","OSL",20));
        flights.add(new Flights(date3, "PAR","ROM",28));
        flights.add(new Flights(date1, "NYC","STK",26));
        flights.add(new Flights(date4, "COP","LDN",30));
        flights.add(new Flights(date8, "HEL","KEF",23));
        flights.add(new Flights(date9, "MRD","IST",38));
        flights.add(new Flights(date5, "MSK","TOK",50));
        flights.add(new Flights(date8, "KIE","PAR",24));
        flights.add(new Flights(date10, "KEF","IST",20));
        flights.add(new Flights(date11, "WAR","KIE",33));
        flights.add(new Flights(date10, "MRD","BAR",40));
        flights.add(new Flights(date12, "TOK","LDN",46));
        flights.add(new Flights(date12, "MSK","TOK",50));

        return flights;
    }

    public ObservableList<Airport> getAirport(){
        ObservableList<Airport> airports = FXCollections.observableArrayList();
        ArrayList<Airport> airports1 = new ArrayList<>();
        airports.add(new Airport(""));
        airports.add(new Airport("KEF"));
        airports.add(new Airport("FRK"));
        airports.add(new Airport("LDN"));
        airports.add(new Airport("BOS"));
        airports.add(new Airport("STK"));
        airports.add(new Airport("MRD"));
        airports.add(new Airport("OSL"));
        airports.add(new Airport("HEL"));
        airports.add(new Airport("PAR"));
        airports.add(new Airport("COP"));
        airports.add(new Airport("ROM"));
        airports.add(new Airport("NYC"));
        airports.add(new Airport("IST"));
        airports.add(new Airport("KIE"));
        airports.add(new Airport("WAR"));
        airports.add(new Airport("BAR"));
        airports.add(new Airport("TOK"));
        airports.add(new Airport("MSK"));
        return airports;
    }
    public ObservableList<Date> getDate(){
        ObservableList<Date> dates = FXCollections.observableArrayList();
        ArrayList<Airport> date = new ArrayList<>();
        dates.add(new Date(""));
        dates.add(new Date("08/07/21"));
        dates.add(new Date("20/03/21"));
        dates.add(new Date("02/09/21"));
        dates.add(new Date("12/04/21"));
        dates.add(new Date("19/11/21"));
        dates.add(new Date("30/12/21"));
        dates.add(new Date("20/02/21"));
        dates.add(new Date("15/01/21"));
        dates.add(new Date("26/08/21"));
        dates.add(new Date("03/10/21"));
        dates.add(new Date("27/09/21"));
        dates.add(new Date("17/06/21"));

        return dates;
    }
}

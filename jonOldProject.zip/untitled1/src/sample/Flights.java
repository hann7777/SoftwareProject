package sample;

import java.util.ArrayList;
import java.util.Date;

public class Flights {
    private String dagsetning;
    private String brottfor;
    private String afangastadur;
    private int capacity;


    public int getCapacity() {
        return capacity;
    }
    public void reduceCapacity(){
        this.capacity = this.capacity-1;
    }

    public void addCapacity(){
        this.capacity = this.capacity+1;
    }
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public Flights(String dagsetning, String brottfor, String afangastadur, int capacity) {
        this.dagsetning = dagsetning;
        this.brottfor = brottfor;
        this.afangastadur = afangastadur;
        this.capacity = capacity;

    }

    @Override
    public String toString() {
        return "From " + brottfor + " to " + afangastadur+", " + dagsetning + ", CAP: " + capacity;
    }

    public String getDagsetning() { return dagsetning; }

    public void setDagsetning(String dagsetning) {
        this.dagsetning = dagsetning;
    }

    public String getBrottfor() {
        return brottfor;
    }

    public void setBrottfor(String brottfor) {
        this.brottfor = brottfor;
    }

    public String getAfangastadur() {
        return afangastadur;
    }

    public void setAfangastadur(String afangastadur) {
        afangastadur = afangastadur;
    }
}

package sample;

public class Reservation {
    public int getBookedSeats() {
        return bookedSeats;
    }


    //for reservations we will use flight and how many seats are booked
    private Flights flight;
    private int bookedSeats;


    public Flights getFlight() {
        return flight;
    }

    public void addCapacity(){
        this.bookedSeats = this.bookedSeats+1;
    }
    public void reduceCapacity(){
        this.bookedSeats = this.bookedSeats-1;
    }


    @Override
    public String toString() {
        return "from " + flight.getBrottfor()+" to "+flight.getAfangastadur()+" on "+
                flight.getDagsetning()+ " for " + bookedSeats;
    }

    public Reservation(Flights flight) {
        this.flight = flight;
    }
}
